VERSION = (1, 5, 31)

default_app_config = 'image.apps.ImageConfig'
